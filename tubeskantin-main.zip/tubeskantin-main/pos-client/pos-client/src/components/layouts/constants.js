export const MENU_LIST = [
    {
        name: 'Home',
        path: '/homeadmin'
    },
    {
        name: 'Pesanan',
        path: '/pesanan'
    },
    {
        name: 'Transaction',
        path: '/transaction'
    },
    {
        name: 'Barang',
        path: '/barang'
    }
]