// // contoh.js

// import React from 'react';
// import Layout from '@/components/layouts/Layout';
// import { useUser } from '@/context/UserContext';
// import styles from '@/styles/Home.module.css';

// const Contoh = () => {
//   const { user } = useUser();

//   return (
//     <Layout>
//       <div className={styles.ok}>
//         <h1>Home</h1>
//         {user && <p>Welcome, {user.username}!</p>}
//       </div>
//       <div className={styles.home}>
//         {/* Your other content goes here */}
//       </div>
//     </Layout>
//   );
// };

// export default Contoh;
